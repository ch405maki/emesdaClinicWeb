# THEME LARAVEL NOVA
# LARAVEL VALET
# https://semaphore.co/account

DB Name: mulkmbjx_emesda_db
Username: mulkmbjx_emesda_user
Password: HgC}YG08?uY1