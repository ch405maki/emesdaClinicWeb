<template>
    <h1>Hello Diagnostic Index!</h1>
</template>