<template>
    <img src="/images/dentallogo.png" alt="Image Logo">
</template>
